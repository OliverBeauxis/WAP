const data = {
    p001: {
        name: "Rychlost větru",
        desc: "abstraktní malba reprezentující dynamiku větru v uzavřeném prostoru",
        author: "Michal Bubílek",
    },
    p002: {
        name: "Vesmír",
        desc: "socha představjící nekonečnost",
        author: "Jiří Grygar",
    },
};